import { execSync } from 'child_process';
import os from 'os';

let handler = async (m, { text }) => {
  try {
    let hostingInfo = await checkHostingInfo();
    return m.reply(hostingInfo);
  } catch (error) {
    return m.reply(`❌ خطأ ف فحص الاستضافة: ${error.message}`);
  }
};

// وظيفة فحص الاستضافة
async function checkHostingInfo() {
  try {
    let result = '╔══════════════════════════════╗\n';
    result += '║     🟢 فحص الاستضافة        ║\n';
    result += '╚══════════════════════════════╝\n\n';

    // معلومات النظام الأساسية
    result += '📊 *معلومات النظام:*\n';
    result += `   └─ النظام: ${os.type()} ${os.release()}\n`;
    result += `   └─ المعالج: ${os.arch()} - ${os.cpus().length} نواة\n`;
    result += `   └─ الرام: ${Math.round(os.totalmem() / (1024 * 1024 * 1024))} GB\n`;
    
    const uptime = Math.floor(os.uptime() / 60);
    result += `   └─ الوقت: ${uptime} دقيقة\n\n`;

    // معلومات Node.js
    result += '📦 *معلومات Node.js:*\n';
    result += `   └─ النسخة: ${process.version}\n\n`;

    // المساحة المتاحة
    result += '💾 *المساحة المتاحة:*\n';
    try {
      const disk = execSync('df -h /', { encoding: 'utf8' });
      const lines = disk.split('\n');
      if (lines[1]) {
        const parts = lines[1].split(/\s+/);
        result += `   └─ المساحة: ${parts[1]} | المستخدم: ${parts[2]} | المتاح: ${parts[3]}\n`;
      }
    } catch (e) {
      result += '   └─ ❌ ماشي قادر نقرا المساحة\n';
    }

    // فحص FFmpeg
    result += '\n🛠️ *فحص FFmpeg:*\n';
    try {
      const ffmpegPath = execSync('which ffmpeg', { encoding: 'utf8' }).trim();
      if (ffmpegPath) {
        result += `   └─ ✅ موجود\n`;
      } else {
        result += '   └─ ❌ ماشي موجود\n';
      }
    } catch (e) {
      result += '   └─ ❌ ماشي موجود\n';
    }

    // فحص الإتصال مع الفيسبوك
    result += '\n📡 *فحص الإتصال مع الفيسبوك:*\n';
    try {
      execSync('timeout 5 curl -s -I https://live-api-s.facebook.com', { stdio: 'ignore' });
      result += '   └─ ✅ الإتصال مزيان\n';
    } catch (e) {
      result += '   └─ ❌ مشكل ف الإتصال\n';
    }

    return result;

  } catch (error) {
    return `❌ خطأ ف الفحص: ${error.message}`;
  }
}

handler.help = ["hosting"];
handler.command = ["hosting", "استضافة", "فحص"];
handler.tags = ["info"];
export default handler;