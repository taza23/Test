import { spawn } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/* ================= CONFIG ================= */

const AUTO_STOP_INTERVAL = 3.916 * 60 * 60 * 1000; // 3h55m
const HEALTH_CHECK_INTERVAL = 60 * 1000;
const MAX_RETRIES = 5;
const STREAM_START_TIMEOUT = 30000; // 30 ثانية

const ADMINS = ['212776537766@s.whatsapp.net'];

/* ================= STORAGE ================= */

const activeStreams = new Map();
const userStreams = new Map();
const stopTimers = new Map();
const healthTimers = new Map();
const streamConfigs = new Map();
const loadingMessages = new Map();

/* ================= HELPERS ================= */

function generateStreamId() {
  return Math.floor(1000 + Math.random() * 9000);
}

function formatDuration(ms) {
  const seconds = Math.floor((ms / 1000) % 60);
  const minutes = Math.floor((ms / (1000 * 60)) % 60);
  const hours = Math.floor(ms / (1000 * 60 * 60));
  return `${hours > 0 ? `${hours}h ` : ''}${minutes}m ${seconds}s`;
}

function isAdmin(userId) {
  return ADMINS.includes(userId);
}

function getSafeUsername(userId) {
  return userId ? (userId.split('@')[0] || 'مجهول') : 'مجهول';
}

function cleanTimers(streamId) {
  if (stopTimers.has(streamId)) clearTimeout(stopTimers.get(streamId));
  if (healthTimers.has(streamId)) clearInterval(healthTimers.get(streamId));
  stopTimers.delete(streamId);
  healthTimers.delete(streamId);
}

async function sendWelcome(conn, chatId, userId) {
  return conn.sendMessage(chatId, {
    text: `👋 مرحباً ${getSafeUsername(userId)}
🎬 نظام البث الاحترافي
⏱️ مدة البث القصوى: 3 ساعات و 55 دقيقة
🔄 إعادة التشغيل: صامتة عند الانقطاع
📖 استخدم /help لعرض جميع الأوامر`
  });
}

/* ================= LOADING MESSAGES ================= */

async function sendLoadingMessage(conn, chatId, streamId) {
  const loadingTexts = [
    "🎬 جاري بدء البث...",
    "⚙️ جاري تهيئة FFmpeg...",
    "📡 جاري الاتصال بالخادم...",
    "🚀 جاري تشغيل البث المباشر..."
  ];

  let currentIndex = 0;

  const loadingInterval = setInterval(async () => {
    if (loadingMessages.has(streamId)) {
      await conn.sendMessage(chatId, {
        text: `${loadingTexts[currentIndex]}\n🆔 رقم البث: ${streamId}\n⏳ الرجاء الانتظار...`
      });
      currentIndex = (currentIndex + 1) % loadingTexts.length;
    }
  }, 5000); // تحديث كل 5 ثواني

  loadingMessages.set(streamId, { interval: loadingInterval, startTime: Date.now() });
}

function removeLoadingMessage(streamId) {
  if (loadingMessages.has(streamId)) {
    clearInterval(loadingMessages.get(streamId).interval);
    loadingMessages.delete(streamId);
  }
}

/* ================= STREAM MANAGEMENT ================= */

async function startFFmpeg(stream) {
  return new Promise((resolve, reject) => {
    // الإعدادات الأصلية البسيطة
    const ffmpegArgs = [
      '-re',          // قراءة بمعدل الوقت الحقيقي
      '-i', stream.source, // مصدر الإدخال
      '-c:v', 'copy', // نسخ الفيديو بدون إعادة ترميز
      '-c:a', 'aac',  // ترميز الصوت إلى AAC
      '-f', 'flv',    // تنسيق الإخراج FLV
      stream.rtmp     // خادم الوجهة
    ];

    console.log(`🚀 تشغيل FFmpeg: ffmpeg ${ffmpegArgs.join(' ')}`);

    const process = spawn('ffmpeg', ffmpegArgs);

    stream.process = process;

    process.on('spawn', () => {
      console.log(`✅ بدأ FFmpeg للبث ${stream.id}`);
      resolve(process);
    });

    process.on('error', (err) => {
      console.error(`❌ خطأ FFmpeg للبث ${stream.id}:`, err);
      reject(err);
    });

    process.stdout.on('data', (data) => {
      console.log(`📊 FFmpeg stdout ${stream.id}:`, data.toString());
    });

    process.stderr.on('data', (data) => {
      console.log(`⚠️ FFmpeg stderr ${stream.id}:`, data.toString());
    });

    process.on('close', (code) => {
      console.log(`🔴 FFmpeg أغلق للبث ${stream.id} مع الكود:`, code);
      if (!stream.manuallyStopped && !stream.timeStopped) {
        handleStreamError(stream, code);
      }
    });
  });
}

async function startStream(conn, chatId, userId, fbKey, source) {
  const streamId = generateStreamId();
  
  // تحقق من المفتاح
  let rtmpUrl;
  if (fbKey.includes('rtmps://') || fbKey.includes('rtmp://')) {
    rtmpUrl = fbKey;
  } else {
    rtmpUrl = `rtmps://live-api-s.facebook.com:443/rtmp/${fbKey}`;
  }
  
  const stream = {
    id: streamId,
    userId,
    chatId,
    source,
    rtmp: rtmpUrl,
    process: null,
    retry: 0,
    manuallyStopped: false,
    timeStopped: false,
    startedAt: Date.now()
  };

  // إرسال رسالة بدء التحميل
  await conn.sendMessage(chatId, {
    text: `🎬 **جارٍ بدء البث...**
🆔 رقم البث: ${streamId}
👤 المستخدم: ${getSafeUsername(userId)}
⏳ يتم الآن تهيئة البث المباشر...
────────────────────
⚠️ قد تستغرق العملية بضع لحظات
✅ ستتلقى إشعاراً عند بدء البث بنجاح`
  });

  // بدء رسائل التحميل الديناميكية
  await sendLoadingMessage(conn, chatId, streamId);

  try {
    activeStreams.set(streamId, stream);
    if (!userStreams.has(userId)) userStreams.set(userId, new Set());
    userStreams.get(userId).add(streamId);

    const ffmpegProcess = await startFFmpeg(stream);

    // إزالة رسالة التحميل وإرسال رسالة النجاح
    removeLoadingMessage(streamId);

    await conn.sendMessage(chatId, {
      text: `✅ **تم بدء البث بنجاح!**
────────────────────
🎬 رقم البث: ${streamId}
👤 المستخدم: ${getSafeUsername(userId)}
📡 الحالة: ● **نشط الآن**
🕐 وقت البدء: ${new Date().toLocaleTimeString()}
⏱️ الإيقاف التلقائي: بعد 3 ساعات و 55 دقيقة
────────────────────
🔧 الميزات:
• ✓ إعادة تشغيل تلقائية
• ✓ مراقبة الصحة
• ✓ إشعارات التحديث
────────────────────
🛑 لإيقاف البث: /stopstream ${streamId}`
    });

    // مؤقت الإيقاف التلقائي
    stopTimers.set(streamId, setTimeout(async () => {
      if (activeStreams.has(streamId)) {
        stream.timeStopped = true;
        await stopStream(conn, chatId, userId, streamId, true);
        await conn.sendMessage(chatId, {
          text: `⏹️ **تم الإيقاف التلقائي للبث**
🆔 رقم البث: ${streamId}
⏱️ المدة: 3 ساعات و 55 دقيقة
✅ تم إكمال المدة القصوى بنجاح`
        });
      }
    }, AUTO_STOP_INTERVAL));

    // نظام مراقبة الصحة
    healthTimers.set(streamId, setInterval(() => {
      if (activeStreams.has(streamId)) {
        const stream = activeStreams.get(streamId);
        // بسيط - فقط تحقق من أن العملية ما زالت تعمل
        if (stream.process && stream.process.exitCode !== null) {
          console.log(`⚠️ البث ${streamId} توقف بشكل غير متوقع`);
        }
      }
    }, HEALTH_CHECK_INTERVAL));

    return streamId;

  } catch (error) {
    // إزالة رسائل التحميل في حالة الخطأ
    removeLoadingMessage(streamId);

    // تنظيف البيانات
    activeStreams.delete(streamId);
    userStreams.get(userId)?.delete(streamId);
    cleanTimers(streamId);

    await conn.sendMessage(chatId, {
      text: `❌ فشل بدء البث
────────────────────
🎬 رقم البث: ${streamId}
🔍 السبب: ${error.message || 'خطأ غير معروف'}
────────────────────
💡 الحلول المقترحة:
1. تحقق من صحة Facebook Stream Key
2. تأكد من أن رابط المصدر يعمل
3. تحقق من اتصال الإنترنت
4. حاول مرة أخرى بعد قليل
────────────────────
🔄 حاول مجدداً باستخدام: /stream <FB_KEY> <SOURCE_URL>`
    });
    console.error(`❌ فشل بدء البث ${streamId}:`, error);
  }
}

async function handleStreamError(stream, code) {
  if (stream.retry < MAX_RETRIES) {
    stream.retry++;
    console.log(`🔄 إعادة المحاولة ${stream.retry}/${MAX_RETRIES} للبث ${stream.id}`);

    // إعادة تشغيل البث بعد تأخير قصير
    setTimeout(async () => {
      try {
        if (activeStreams.has(stream.id) && !stream.manuallyStopped && !stream.timeStopped) {
          const newProcess = await startFFmpeg(stream);
          console.log(`✅ تمت إعادة التشغيل للبث ${stream.id}`);
        }
      } catch (error) {
        console.error(`❌ فشل إعادة التشغيل للبث ${stream.id}:`, error);
      }
    }, 5000);
  } else {
    console.log(`🚫 تجاوز الحد الأقصى لإعادة المحاولة للبث ${stream.id}`);
    // تنظيف البيانات
    activeStreams.delete(stream.id);
    userStreams.get(stream.userId)?.delete(stream.id);
    cleanTimers(stream.id);
  }
}

async function stopStream(conn, chatId, userId, streamId, forced = false) {
  const stream = activeStreams.get(streamId);
  if (!stream) return;

  if (!forced && stream.userId !== userId) {
    return conn.sendMessage(chatId, {
      text: '❌ لا تملك صلاحية إيقاف هذا البث'
    });
  }

  stream.manuallyStopped = true;
  cleanTimers(streamId);
  removeLoadingMessage(streamId);
  stream.process?.kill('SIGTERM');

  activeStreams.delete(streamId);
  userStreams.get(stream.userId)?.delete(streamId);

  const duration = Date.now() - stream.startedAt;

  await conn.sendMessage(chatId, {
    text: `⏹️ **تم إيقاف البث بنجاح**
────────────────────
🎬 رقم البث: ${streamId}
👤 بواسطة: ${forced ? '👑 Admin' : '👤 المالك'}
⏱️ المدة: ${formatDuration(duration)}
🕐 وقت الإيقاف: ${new Date().toLocaleTimeString()}
────────────────────
✅ تم إيقاف جميع العمليات
📊 تم تحرير الموارد`
  });
}

/* ================= ADMIN COMMANDS ================= */

async function listStreams(conn, chatId) {
  if (activeStreams.size === 0) {
    return conn.sendMessage(chatId, {
      text: '📭 لا توجد بثوص نشطة حالياً'
    });
  }

  let msg = '📡 البثوص النشطة حاليًا\n────────────────────\n\n';

  for (const [id, s] of activeStreams) {
    const duration = Date.now() - s.startedAt;
    msg += `🎬 **البث #${id}**
👤 المستخدم: ${getSafeUsername(s.userId)}
⏱️ المدة: ${formatDuration(duration)}
📡 الحالة: ● نشط
────────────────────\n`;
  }

  msg += `\n📊 **الإجمالي:** ${activeStreams.size} بث نشط`;

  conn.sendMessage(chatId, { text: msg });
}

async function userInfo(conn, chatId, target) {
  const active = userStreams.get(target)?.size || 0;
  
  conn.sendMessage(chatId, {
    text: `👤 **معلومات المستخدم**
────────────────────
🆔 ${target}
👤 الاسم: ${getSafeUsername(target)}
🔴 البثوص النشطة: ${active}
────────────────────
${active > 0 ? '✅ **يوجد بثوص نشطة**' : '📭 **لا توجد بثوص نشطة**'}`
  });
}

async function forceStopAllStreams(conn, chatId) {
  if (activeStreams.size === 0) {
    return conn.sendMessage(chatId, {
      text: '📭 لا توجد بثوص نشطة'
    });
  }

  const count = activeStreams.size;
  const streamsToStop = Array.from(activeStreams.keys());

  for (const streamId of streamsToStop) {
    const stream = activeStreams.get(streamId);
    if (stream) {
      stream.manuallyStopped = true;
      cleanTimers(streamId);
      removeLoadingMessage(streamId);
      stream.process?.kill('SIGTERM');
      activeStreams.delete(streamId);
      userStreams.get(stream.userId)?.delete(streamId);
    }
  }

  return conn.sendMessage(chatId, {
    text: `✅ **تم إيقاف جميع البثوص**
📊 تم إيقاف: ${count} بث
✅ جميع العمليات متوقفة`
  });
}

/* ================= HELP COMMAND ================= */

async function handleHelp(conn, chatId, userId) {
  const isUserAdmin = isAdmin(userId);
  const adminPart = isUserAdmin ? `
🛡️ **أوامر Admin**
────────────────────
/streamlist – عرض جميع البثوص النشطة
/forcestop <id> – إيقاف أي بث
/forcestopall – إيقاف جميع البثوص
/userinfo <user> – معلومات مستخدم
────────────────────
` : '';

  return conn.sendMessage(chatId, {
    text: `🎉 مرحباً بك في نظام البث الاحترافي
────────────────────

🎬 الميزات المتقدمة:
• ✅ بث مستقر بواسطة FFmpeg
• 🔄 إعادة تشغيل صامتة عند الانقطاع
• ⏱️ إيقاف تلقائي بعد 3 ساعات و 55 دقيقة
• 📊 عدد غير محدود من البثوص
• 👑 نظام Admin متكامل
• 💬 إشعارات تفصيلية

👤 أوامر المستخدم:
────────────────────
/stream <FB_KEY> <SOURCE_URL> – بدء بث جديد
/stopstream <STREAM_ID> – إيقاف بث محدد
/stopallstreams – إيقاف جميع بثوصك
/help – عرض هذه التعليمات
────────────────────

${adminPart}

💡 ملاحظات هامة:
• أي توقف قبل 3h55m → يعاود التشغيل تلقائياً
• بعد 3h55m → يتوقف نهائياً
• ستتلقى إشعارات عند كل مرحلة
• البث يبدأ بعد 10-30 ثانية من الأمر

🔧 الدعم:
للمساعدة تواصل مع المطور`
  });
}

/* ================= MAIN HANDLER ================= */

const handler = async (m, { conn, text, usedPrefix, command, sender }) => {
  const chatId = m.chat;
  const userId = sender;

  try {
    // إرسال رسالة الترحيب فقط مع الأوامر الأساسية
    const basicCommands = ['help', 'stream', 'streamlist'];
    if (basicCommands.includes(command.toLowerCase())) {
      await sendWelcome(conn, chatId, userId);
    }

    if (command.toLowerCase() === 'stream') {
      if (!text) {
        return conn.sendMessage(chatId, {
          text: `❌ **صيغة غير صحيحة**
────────────────────
💡 **الصيغة الصحيحة:**
/stream <FB_KEY> <SOURCE_URL>
────────────────────
📝 **مثال:**
/stream 1234567890abcdef https://example.com/stream.m3u8
────────────────────
🔑 **Facebook Stream Key:**
احصل عليه من صفحة البث المباشر على Facebook
🔗 **رابط المصدر:**
يجب أن يكون رابط فيديو مباشر (m3u8, mp4, etc.)`
        });
      }

      const parts = text.trim().split(/\s+/);
      if (parts.length < 2) {
        return conn.sendMessage(chatId, {
          text: '❌ يجب إدخال كل من Facebook Stream Key ورابط المصدر'
        });
      }

      const key = parts[0];
      const source = parts.slice(1).join(' ');

      return await startStream(conn, chatId, userId, key, source);
    }

    if (command.toLowerCase() === 'stopstream') {
      if (!text) {
        return conn.sendMessage(chatId, {
          text: '❌ يجب إدخال رقم البث\nمثال: /stopstream 1234'
        });
      }

      const streamId = parseInt(text.trim());
      if (isNaN(streamId)) {
        return conn.sendMessage(chatId, {
          text: '❌ رقم البث غير صالح'
        });
      }

      return await stopStream(conn, chatId, userId, streamId);
    }

    if (command.toLowerCase() === 'stopallstreams') {
      const userStreamIds = userStreams.get(userId);
      if (!userStreamIds || userStreamIds.size === 0) {
        return conn.sendMessage(chatId, {
          text: '📭 لا توجد بثوص نشطة لديك'
        });
      }

      for (const streamId of userStreamIds) {
        await stopStream(conn, chatId, userId, streamId);
      }

      return conn.sendMessage(chatId, {
        text: '✅ تم إيقاف جميع بثوصك بنجاح'
      });
    }

    if (command.toLowerCase() === 'streamlist') {
      if (!isAdmin(userId)) {
        return conn.sendMessage(chatId, {
          text: '❌ هذا الأمر متاح فقط للمشرفين'
        });
      }
      return await listStreams(conn, chatId);
    }

    if (command.toLowerCase() === 'forcestop') {
      if (!isAdmin(userId)) {
        return conn.sendMessage(chatId, {
          text: '❌ هذا الأمر متاح فقط للمشرفين'
        });
      }

      if (!text) {
        return conn.sendMessage(chatId, {
          text: '❌ يجب إدخال رقم البث\nمثال: /forcestop 1234'
        });
      }

      const streamId = parseInt(text.trim());
      if (isNaN(streamId)) {
        return conn.sendMessage(chatId, {
          text: '❌ رقم البث غير صالح'
        });
      }

      return await stopStream(conn, chatId, userId, streamId, true);
    }

    if (command.toLowerCase() === 'forcestopall') {
      if (!isAdmin(userId)) {
        return conn.sendMessage(chatId, {
          text: '❌ هذا الأمر متاح فقط للمشرفين'
        });
      }

      return await forceStopAllStreams(conn, chatId);
    }

    if (command.toLowerCase() === 'userinfo') {
      if (!isAdmin(userId)) {
        return conn.sendMessage(chatId, {
          text: '❌ هذا الأمر متاح فقط للمشرفين'
        });
      }

      if (!text) {
        return conn.sendMessage(chatId, {
          text: '❌ يجب إدخال معرف المستخدم\nمثال: /userinfo 123456789@s.whatsapp.net'
        });
      }

      return await userInfo(conn, chatId, text.trim());
    }

    if (command.toLowerCase() === 'help') {
      return await handleHelp(conn, chatId, userId);
    }

  } catch (error) {
    console.error('❌ خطأ في المعالج:', error);
    return conn.sendMessage(chatId, {
      text: `❌ **حدث خطأ غير متوقع**\n🔍 التفاصيل: ${error.message || 'خطأ غير معروف'}\n🔄 الرجاء المحاولة مرة أخرى لاحقاً`
    });
  }
}

handler.help = [
  'stream <fb_key> <url> - بدء بث جديد',
  'stopstream <id> - إيقاف بث محدد',
  'stopallstreams - إيقاف جميع بثوصك',
  'streamlist - عرض البثوص النشطة (Admin)',
  'forcestop <id> - إيقاف أي بث (Admin)',
  'forcestopall - إيقاف جميع البثوص (Admin)',
  'userinfo <user> - معلومات مستخدم (Admin)',
  'help - عرض التعليمات'
]

handler.tags = ['stream']

handler.command = [
  /^stream$/i,
  /^stopstream$/i,
  /^stopallstreams$/i,
  /^streamlist$/i,
  /^forcestop$/i,
  /^forcestopall$/i,
  /^userinfo$/i,
  /^help$/i
]

export default handler;


